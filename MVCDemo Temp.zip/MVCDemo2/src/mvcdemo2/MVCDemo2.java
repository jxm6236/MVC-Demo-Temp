/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mvcdemo2;

/**
 *
 * @author jxm6236
 */
public class MVCDemo2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        TemperatureModel temperature = new TemperatureModel();
        new FarenheitGUI(temperature, 100, 100);
	new CelsiusGUI(temperature, 100, 250);
        new GraphGUI(temperature, 250, 500);
        new SliderGUI(temperature, 250 ,250);
    }
    
}
